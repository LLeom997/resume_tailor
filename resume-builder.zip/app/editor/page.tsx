'use client'

import { useRouter } from 'next/navigation'
import { ResumeEditor } from '@/components/resume-editor'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'
import { mockResumeData } from '@/lib/mock-resume'

export default function EditorPage() {
  const router = useRouter()

  const handleSave = () => {
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        <div className="mb-8 flex items-center gap-4">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Create Master Resume</h1>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <ResumeEditor initialContent={mockResumeData} isMaster={true} onSave={handleSave} />
        </div>
      </div>
    </div>
  )
}
