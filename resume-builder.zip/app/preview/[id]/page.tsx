'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { useSession } from '@/lib/session-context'
import { Resume } from '@/lib/types'
import { ResumePreview } from '@/components/resume-preview'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import { ArrowLeft, Download, Loader2 } from 'lucide-react'
import { exportToText } from '@/lib/resume-utils'

export default function PreviewPage() {
  const router = useRouter()
  const params = useParams()
  const { sessionId, isLoading } = useSession()
  const [resume, setResume] = useState<Resume | null>(null)
  const [isLoadingResume, setIsLoadingResume] = useState(true)
  const [template, setTemplate] = useState<'classic' | 'modern'>('classic')

  const id = params.id as string

  useEffect(() => {
    if (!sessionId || isLoading || !id) return

    fetchResume()
  }, [sessionId, isLoading, id])

  const fetchResume = async () => {
    if (!sessionId) return

    try {
      const response = await fetch(`/api/resumes/${id}`, {
        headers: {
          'x-session-id': sessionId,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setResume(data)
      } else {
        router.push('/dashboard')
      }
    } catch (error) {
      console.error('Error fetching resume:', error)
      router.push('/dashboard')
    } finally {
      setIsLoadingResume(false)
    }
  }

  const handleDownload = () => {
    if (!resume) return

    const text = exportToText(resume.content)
    const element = document.createElement('a')
    element.setAttribute(
      'href',
      'data:text/plain;charset=utf-8,' + encodeURIComponent(text)
    )
    element.setAttribute('download', `${resume.name}.txt`)
    element.style.display = 'none'
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  const handlePrint = () => {
    window.print()
  }

  if (isLoading || isLoadingResume) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    )
  }

  if (!resume) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <p className="text-gray-600">Resume not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto py-8 px-4">
        {/* Header with controls */}
        <div className="mb-8 bg-white rounded-lg shadow p-6 sticky top-0 z-10">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Link href="/dashboard">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">{resume.name}</h1>
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
              <Button variant="outline" onClick={handlePrint}>
                Print
              </Button>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              variant={template === 'classic' ? 'default' : 'outline'}
              onClick={() => setTemplate('classic')}
            >
              Classic
            </Button>
            <Button
              variant={template === 'modern' ? 'default' : 'outline'}
              onClick={() => setTemplate('modern')}
            >
              Modern
            </Button>
          </div>
        </div>

        {/* Preview */}
        <div className="bg-white rounded-lg shadow overflow-hidden print:shadow-none">
          <div className="print:p-0 p-4">
            <ResumePreview content={resume.content} template={template} />
          </div>
        </div>
      </div>
    </div>
  )
}
