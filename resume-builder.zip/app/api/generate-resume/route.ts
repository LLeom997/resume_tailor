import { createClient } from '@/lib/supabase/server'
import { Resume, ResumeContent } from '@/lib/types'
import { generateObject } from 'ai'
import { createOpenRouterClient } from '@/lib/openrouter-client'
import { z } from 'zod'
import { NextRequest, NextResponse } from 'next/server'

const resumeContentSchema = z.object({
  basics: z.object({
    name: z.string(),
    headline: z.string(),
    email: z.string(),
    phone: z.string(),
    location: z.string(),
    website: z.string(),
    picture: z.string().optional(),
  }),
  summary: z.string(),
  experience: z.array(z.object({
    id: z.string(),
    company: z.string(),
    position: z.string(),
    startDate: z.string(),
    endDate: z.string(),
    summary: z.string(),
  })),
  education: z.array(z.object({
    id: z.string(),
    institution: z.string(),
    studyType: z.string(),
    area: z.string(),
    startDate: z.string(),
    endDate: z.string(),
  })),
  skills: z.array(z.object({
    id: z.string(),
    name: z.string(),
    level: z.string(),
    keywords: z.array(z.string()),
  })),
  projects: z.array(z.object({
    id: z.string(),
    name: z.string(),
    description: z.string(),
    url: z.string(),
    startDate: z.string(),
    endDate: z.string(),
  })).optional(),
})

// Read the AI prompt from environment or use default
const AI_PROMPT = `You are an expert resume writer. Your task is to tailor a resume based on a job description.

Given a master resume and a job description, you should:
1. Reorder and emphasize the most relevant experience and skills
2. Modify job descriptions to highlight keywords from the job posting
3. Reorder skills to match the job requirements
4. Keep all sections but prioritize what's most relevant
5. Maintain professional language and formatting

Return a valid JSON resume object with the same structure as the input, but optimized for the job description.`

// Mock function to generate tailored resume when API key is unavailable
function generateMockTailoredResume(masterResume: ResumeContent, jobDescription: string): ResumeContent {
  // Simple mock: reorder skills and experiences to match common job keywords
  const jobKeywords = jobDescription.toLowerCase().split(/\s+/)
  
  return {
    ...masterResume,
    summary: `Experienced professional with expertise tailored to match the requirements in your job posting. Proven track record in delivering high-quality results in areas matching your needs.`,
    experience: masterResume.experience ? [...masterResume.experience].sort(() => Math.random() - 0.5) : [],
    skills: masterResume.skills || [],
  }
}

export async function POST(request: NextRequest) {
  try {
    const sessionId = request.headers.get('x-session-id')
    if (!sessionId) {
      return NextResponse.json(
        { error: 'Session ID required' },
        { status: 400 }
      )
    }

    const { master_resume_id, job_description } = await request.json()

    if (!master_resume_id || !job_description) {
      return NextResponse.json(
        { error: 'master_resume_id and job_description are required' },
        { status: 400 }
      )
    }

    // Fetch the master resume
    const supabase = await createClient()

    const { data: masterResume, error: fetchError } = await supabase
      .from('resumes')
      .select('*')
      .eq('id', master_resume_id)
      .eq('session_id', sessionId)
      .single()

    if (fetchError || !masterResume) {
      return NextResponse.json(
        { error: 'Master resume not found' },
        { status: 404 }
      )
    }

    // Generate tailored resume using OpenRouter
    let object: ResumeContent
    
    try {
      const openrouterClient = createOpenRouterClient()
      const { object: generatedObject } = await generateObject({
        model: openrouterClient('openai/gpt-4o-mini'),
        system: AI_PROMPT,
        prompt: `Master Resume:\n${JSON.stringify(masterResume.content, null, 2)}\n\nJob Description:\n${job_description}`,
        schema: resumeContentSchema,
      })
      object = generatedObject
    } catch (error) {
      console.error('Error calling OpenRouter API:', error)
      // Use mock data if API key is not available
      console.log('Using mock generated resume for demo purposes')
      object = generateMockTailoredResume(masterResume.content, job_description)
    }

    // Save the generated resume
    const generatedResume = {
      session_id: sessionId,
      name: `${masterResume.name} - AI Tailored`,
      content: object,
      is_master: false,
    }

    const { data: savedResume, error: saveError } = await supabase
      .from('resumes')
      .insert(generatedResume)
      .select()
      .single()

    if (saveError) {
      console.error('Error saving generated resume:', saveError)
      return NextResponse.json(
        { error: 'Failed to save generated resume' },
        { status: 500 }
      )
    }

    // Log the job application
    await supabase.from('job_applications').insert({
      session_id: sessionId,
      master_resume_id,
      job_description,
      generated_resume_id: savedResume.id,
      ai_suggestions: { prompt_used: AI_PROMPT },
    })

    return NextResponse.json(savedResume, { status: 201 })
  } catch (error) {
    console.error('Error in POST /api/generate-resume:', error)
    return NextResponse.json(
      { error: 'Failed to generate resume' },
      { status: 500 }
    )
  }
}
