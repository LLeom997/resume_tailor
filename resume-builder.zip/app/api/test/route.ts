import { NextResponse } from 'next/server'

export async function GET() {
  return NextResponse.json({
    message: 'API is working',
    supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ? '✓' : '✗',
    supabaseKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? '✓' : '✗',
  })
}
