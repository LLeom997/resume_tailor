'use client'

import { useState } from 'react'
import { Resume } from '@/lib/types'
import { useSession } from '@/lib/session-context'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { AlertCircle, Loader2 } from 'lucide-react'

interface AIGeneratorProps {
  masterResume: Resume
  onGenerateComplete?: (generatedResume: Resume) => void
}

export function AIGenerator({ masterResume, onGenerateComplete }: AIGeneratorProps) {
  const { sessionId } = useSession()
  const [jobDescription, setJobDescription] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleGenerate = async () => {
    if (!sessionId || !jobDescription.trim()) {
      setError('Please enter a job description')
      return
    }

    setIsGenerating(true)
    setError(null)

    try {
      const response = await fetch('/api/generate-resume', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': sessionId,
        },
        body: JSON.stringify({
          master_resume_id: masterResume.id,
          job_description: jobDescription,
        }),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || 'Failed to generate resume')
      }

      const generatedResume = await response.json()
      onGenerateComplete?.(generatedResume)
      setJobDescription('')
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error'
      setError(message)
      console.error('Error generating resume:', err)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Resume Tailor</CardTitle>
        <CardDescription>
          Paste a job description and let AI tailor your resume for this specific role
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium">Job Description</label>
          <Textarea
            value={jobDescription}
            onChange={(e) => {
              setJobDescription(e.target.value)
              setError(null)
            }}
            placeholder="Paste the complete job description here..."
            rows={8}
            disabled={isGenerating}
          />
        </div>

        {error && (
          <div className="flex gap-2 p-3 bg-red-50 border border-red-200 rounded-md">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <Button
          onClick={handleGenerate}
          disabled={isGenerating || !jobDescription.trim()}
          className="w-full"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Generating...
            </>
          ) : (
            'Generate Tailored Resume'
          )}
        </Button>

        <p className="text-xs text-gray-600">
          This will create a new resume variant optimized for the job description using AI.
          Your master resume will remain unchanged.
        </p>
      </CardContent>
    </Card>
  )
}
