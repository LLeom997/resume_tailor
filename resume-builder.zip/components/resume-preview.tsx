'use client'

import { ResumeContent } from '@/lib/types'
import { formatDate } from '@/lib/resume-utils'

interface ResumePreviewProps {
  content: ResumeContent
  template?: 'classic' | 'modern'
}

export function ResumePreview({ content, template = 'classic' }: ResumePreviewProps) {
  if (template === 'modern') {
    return <ModernTemplate content={content} />
  }

  return <ClassicTemplate content={content} />
}

function ClassicTemplate({ content }: { content: ResumeContent }) {
  return (
    <div className="bg-white p-8 text-black space-y-6 text-sm leading-relaxed">
      {/* Header */}
      <div className="border-b-2 border-black pb-4">
        <h1 className="text-2xl font-bold">{content.basics.name}</h1>
        <p className="text-gray-700">{content.basics.headline}</p>
        <div className="mt-2 space-y-1 text-xs">
          <p>{content.basics.email}</p>
          <p>{content.basics.phone}</p>
          <p>{content.basics.location}</p>
          {content.basics.website && <p>{content.basics.website}</p>}
        </div>
      </div>

      {/* Summary */}
      {content.summary && (
        <div>
          <h2 className="font-bold text-sm mb-2 uppercase tracking-wide">
            Professional Summary
          </h2>
          <p className="text-gray-700">{content.summary}</p>
        </div>
      )}

      {/* Experience */}
      {content.experience && content.experience.length > 0 && (
        <div>
          <h2 className="font-bold text-sm mb-3 uppercase tracking-wide border-b border-black pb-1">
            Experience
          </h2>
          <div className="space-y-3">
            {content.experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">{exp.position}</p>
                    <p className="text-gray-600">{exp.company}</p>
                  </div>
                  <p className="text-xs text-gray-600">
                    {formatDate(exp.startDate)} - {formatDate(exp.endDate)}
                  </p>
                </div>
                <p className="text-gray-700 mt-1">{exp.summary}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {content.education && content.education.length > 0 && (
        <div>
          <h2 className="font-bold text-sm mb-3 uppercase tracking-wide border-b border-black pb-1">
            Education
          </h2>
          <div className="space-y-2">
            {content.education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">
                      {edu.studyType} in {edu.area}
                    </p>
                    <p className="text-gray-600">{edu.institution}</p>
                  </div>
                  <p className="text-xs text-gray-600">
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {content.skills && content.skills.length > 0 && (
        <div>
          <h2 className="font-bold text-sm mb-3 uppercase tracking-wide border-b border-black pb-1">
            Skills
          </h2>
          <div className="space-y-2">
            {content.skills.map((skill) => (
              <div key={skill.id}>
                <p className="font-semibold">{skill.name}</p>
                <p className="text-gray-700">{skill.keywords.join(', ')}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects */}
      {content.projects && content.projects.length > 0 && (
        <div>
          <h2 className="font-bold text-sm mb-3 uppercase tracking-wide border-b border-black pb-1">
            Projects
          </h2>
          <div className="space-y-3">
            {content.projects.map((project) => (
              <div key={project.id}>
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">{project.name}</p>
                    <p className="text-gray-700">{project.description}</p>
                    {project.url && (
                      <p className="text-blue-600 text-xs">{project.url}</p>
                    )}
                  </div>
                  <p className="text-xs text-gray-600">
                    {formatDate(project.startDate)} - {formatDate(project.endDate)}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function ModernTemplate({ content }: { content: ResumeContent }) {
  return (
    <div className="bg-white p-8 text-black space-y-6 text-sm">
      {/* Two-column layout */}
      <div className="grid grid-cols-3 gap-6">
        {/* Left column - Contact info */}
        <div className="col-span-1 border-r border-gray-300 pr-6">
          <h1 className="text-xl font-bold mb-1">{content.basics.name}</h1>
          <p className="text-xs text-gray-600 mb-4">{content.basics.headline}</p>

          <div className="space-y-3">
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase">Contact</p>
              <div className="text-xs space-y-1 mt-2">
                <p>{content.basics.email}</p>
                <p>{content.basics.phone}</p>
                <p>{content.basics.location}</p>
                {content.basics.website && <p>{content.basics.website}</p>}
              </div>
            </div>

            {/* Skills in sidebar */}
            {content.skills && content.skills.length > 0 && (
              <div>
                <p className="text-xs font-semibold text-gray-500 uppercase">Skills</p>
                <div className="text-xs space-y-2 mt-2">
                  {content.skills.map((skill) => (
                    <div key={skill.id}>
                      <p className="font-semibold">{skill.name}</p>
                      <p className="text-gray-600">{skill.keywords.join(', ')}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right column - Main content */}
        <div className="col-span-2">
          {/* Summary */}
          {content.summary && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-2">
                Professional Summary
              </p>
              <p className="text-gray-700">{content.summary}</p>
            </div>
          )}

          {/* Experience */}
          {content.experience && content.experience.length > 0 && (
            <div className="mb-6">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-3">
                Experience
              </p>
              <div className="space-y-3">
                {content.experience.map((exp) => (
                  <div key={exp.id}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">{exp.position}</p>
                        <p className="text-gray-600">{exp.company}</p>
                      </div>
                      <p className="text-xs text-gray-600">
                        {formatDate(exp.startDate)} - {formatDate(exp.endDate)}
                      </p>
                    </div>
                    <p className="text-gray-700 mt-1 text-xs">{exp.summary}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Education */}
          {content.education && content.education.length > 0 && (
            <div>
              <p className="text-xs font-semibold text-gray-500 uppercase mb-3">
                Education
              </p>
              <div className="space-y-2">
                {content.education.map((edu) => (
                  <div key={edu.id}>
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-semibold">
                          {edu.studyType} in {edu.area}
                        </p>
                        <p className="text-gray-600">{edu.institution}</p>
                      </div>
                      <p className="text-xs text-gray-600">
                        {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Projects */}
          {content.projects && content.projects.length > 0 && (
            <div className="mt-6">
              <p className="text-xs font-semibold text-gray-500 uppercase mb-3">
                Projects
              </p>
              <div className="space-y-3">
                {content.projects.map((project) => (
                  <div key={project.id}>
                    <p className="font-semibold">{project.name}</p>
                    <p className="text-gray-700 text-xs">{project.description}</p>
                    {project.url && (
                      <p className="text-blue-600 text-xs">{project.url}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
