'use client'

import { Resume, ResumeContent } from '@/lib/types'
import { useSession } from '@/lib/session-context'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

interface ResumeEditorProps {
  resume?: Resume
  initialContent?: ResumeContent
  onSave?: (resume: Resume) => void
  isMaster?: boolean
}

export function ResumeEditor({ resume, initialContent, onSave, isMaster = false }: ResumeEditorProps) {
  const { sessionId } = useSession()
  const [isSaving, setIsSaving] = useState(false)
  const [content, setContent] = useState<ResumeContent>(
    resume?.content || initialContent || {
      basics: {
        name: '',
        headline: '',
        email: '',
        phone: '',
        location: '',
        website: '',
      },
      summary: '',
      experience: [],
      education: [],
      skills: [],
    }
  )

  const handleSave = async () => {
    if (!sessionId) return

    setIsSaving(true)
    try {
      const url = resume
        ? `/api/resumes/${resume.id}`
        : '/api/resumes'
      
      const method = resume ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'x-session-id': sessionId,
        },
        body: JSON.stringify({
          name: content.basics.name || 'Untitled Resume',
          content,
          is_master: isMaster,
        }),
      })

      if (!response.ok) throw new Error('Failed to save resume')

      const savedResume = await response.json()
      onSave?.(savedResume)
    } catch (error) {
      console.error('Error saving resume:', error)
      alert('Failed to save resume')
    } finally {
      setIsSaving(false)
    }
  }

  const updateBasics = (field: keyof typeof content.basics, value: string) => {
    setContent({
      ...content,
      basics: { ...content.basics, [field]: value },
    })
  }

  return (
    <div className="space-y-6">
      {/* Basic Information */}
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Full Name</label>
              <Input
                value={content.basics.name}
                onChange={(e) => updateBasics('name', e.target.value)}
                placeholder="John Doe"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Professional Headline</label>
              <Input
                value={content.basics.headline}
                onChange={(e) => updateBasics('headline', e.target.value)}
                placeholder="Full Stack Developer"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Email</label>
              <Input
                value={content.basics.email}
                onChange={(e) => updateBasics('email', e.target.value)}
                placeholder="john@example.com"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Phone</label>
              <Input
                value={content.basics.phone}
                onChange={(e) => updateBasics('phone', e.target.value)}
                placeholder="+1 (555) 000-0000"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Location</label>
              <Input
                value={content.basics.location}
                onChange={(e) => updateBasics('location', e.target.value)}
                placeholder="San Francisco, CA"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Website</label>
              <Input
                value={content.basics.website}
                onChange={(e) => updateBasics('website', e.target.value)}
                placeholder="https://example.com"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Professional Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Professional Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            value={content.summary}
            onChange={(e) => setContent({ ...content, summary: e.target.value })}
            placeholder="Brief overview of your professional background and goals"
            rows={4}
          />
        </CardContent>
      </Card>

      {/* Save Button */}
      <Button
        onClick={handleSave}
        disabled={isSaving}
        className="w-full"
      >
        {isSaving ? 'Saving...' : 'Save Resume'}
      </Button>
    </div>
  )
}
