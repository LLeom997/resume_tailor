export interface ResumeContent {
  basics: {
    name: string
    headline: string
    email: string
    phone: string
    location: string
    website: string
    picture?: string
  }
  summary: string
  experience: Array<{
    id: string
    company: string
    position: string
    startDate: string
    endDate: string
    summary: string
  }>
  education: Array<{
    id: string
    institution: string
    studyType: string
    area: string
    startDate: string
    endDate: string
  }>
  skills: Array<{
    id: string
    name: string
    level: string
    keywords: string[]
  }>
  projects?: Array<{
    id: string
    name: string
    description: string
    url: string
    startDate: string
    endDate: string
  }>
}

export interface Resume {
  id: string
  session_id: string
  name: string
  content: ResumeContent
  is_master: boolean
  created_at: string
  updated_at: string
}

export interface JobApplication {
  id: string
  session_id: string
  master_resume_id: string
  job_description: string
  generated_resume_id?: string
  ai_suggestions?: Record<string, unknown>
  created_at: string
  updated_at: string
}

export interface GenerateResumeRequest {
  master_resume_id: string
  job_description: string
}

export interface GenerateResumeResponse {
  success: boolean
  resume?: Resume
  error?: string
}
