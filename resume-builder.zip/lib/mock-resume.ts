import { ResumeContent } from './types'

export const mockResumeData: ResumeContent = {
  basics: {
    name: 'Maitreya Gokhale',
    headline: 'Mechanical Design Engineer | 6+ Years | NPI & End-to-End Product Development',
    email: 'mngokhale89@gmail.com',
    phone: '+91 940447 9387',
    location: '',
    website: '',
  },
  summary:
    'Design and Manufacturing Engineer driving end to end product development across Home Appliances and Industrial Turbine Pump platforms, with proven expertise in plastic components, sheet metal, and castings, spanning chassis architecture, system packaging, design validation. Proficient in Ansys, UG NX, Creo Parametric, SolidWorks, CATIA, GD&T (ASME Y14.5), DFMEA, DFM/DFA, tolerance analysis (CETOL), and PLM (Windchill). Demonstrated impact in VAVE-driven cost reduction, V&V execution, and cross-functional leadership across Design, Quality, and Manufacturing.',
  experience: [
    {
      id: '1',
      company: 'Whirlpool of India Pvt. Ltd.',
      position: 'Mechanical Engineer NPD',
      startDate: 'Jul 2023',
      endDate: 'Present',
      summary:
        'End-to-End NPI Ownership – Led 6+ full-cycle programs (concept → DV → PV → SOP) across chassis, packaging, and system design via Creo and Windchill PLM; managed vendor prototyping schedules and coordinated ECR/ECO across operations, quality, and product design. Design Validation & V&V – Built FEA and thermal CFD digital twin framework; validated builds via rapid prototyping (PLA, SLA, ABS/FDM) for form, fit, and function; reduced DV cycle 6 to 3 months, cut physical test iterations by 40%. Thermal Architecture – Developed ventilation concepts for built-in oven airflow, maintaining cabinet temps <65°C. VAVE and Cost Optimization – Eliminated $3/unit material cost, ~$3M annual savings across 1M+ units. DFMEA and Risk Mitigation – Reduced part complexity by 27% across 50+ SKUs. Data-Driven Digital Design & AI Integration – Automated collection and structuring of field sensor data via vendor API using Python and VBA.',
    },
    {
      id: '2',
      company: 'Whirlpool of India Pvt. Ltd.',
      position: 'CAE Engineer',
      startDate: 'Sep 2022',
      endDate: 'Jul 2023',
      summary:
        'Structural FEA & Simulation Validation – Executed structural FEA on refrigeration chassis; drove DTC and early-stage VE decisions; developed hyperelastic silicone material models improving simulation-to-test correlation. Measurement System Design & V&V – Engineered extraction force validation jig for glass trim assembly; standardized across DV gates.',
    },
    {
      id: '3',
      company: 'Chinmay Infra',
      position: 'Mechanical Engineer',
      startDate: '2021',
      endDate: '2022',
      summary:
        'End-to-End Product Development – Owned full system design (concept to build to validation) for automated hydraulic machinery; delivered 150-ton hydraulic press at Rs. 14.75L vs Rs. 25L benchmark, 41% under cost target. System Integration and Design Validation – Integrated mechanical, hydraulic, and control systems.',
    },
    {
      id: '4',
      company: 'Aditya Hydrotech',
      position: 'Associate Engineer (NPD/VAVE)',
      startDate: '2019',
      endDate: '2021',
      summary:
        'Product Design and Development – Designed and released VT pump assemblies (250 to 2500 HP); managed full lifecycle from concept to drawing release. DFM/DFA and Cost Optimization – Eliminated in-house machining via external sourcing; reduced cost, lead time, and rejection risk. Field Validation and Commissioning – Performed hydraulic selection analysis.',
    },
  ],
  education: [
    {
      id: '1',
      institution: 'Walchand College of Engineering',
      studyType: 'M.Tech',
      area: 'Design Engineering',
      startDate: '2021',
      endDate: '2023',
    },
    {
      id: '2',
      institution: 'Shivaji University',
      studyType: 'B.E.',
      area: 'Mechanical Engineering',
      startDate: '2015',
      endDate: '2019',
    },
  ],
  skills: [
    {
      id: '1',
      name: 'CAD',
      level: 'Expert',
      keywords: ['Siemens NX (certified)', 'Creo Parametric (certified)', 'Creo Direct', 'SolidWorks (certified)', 'CATIA', 'AutoCAD'],
    },
    {
      id: '2',
      name: 'CAE / Simulation',
      level: 'Expert',
      keywords: ['ANSYS Workbench', 'HyperMesh', 'FEA (structural + thermal)', 'LS-DYNA'],
    },
    {
      id: '3',
      name: 'Methods',
      level: 'Expert',
      keywords: ['GD&T (ASME Y14.5 & ISO)', 'Tolerance stack-up', 'DFMEA', 'DFM/DFA', 'CETOL'],
    },
    {
      id: '4',
      name: 'Languages / Automation',
      level: 'Intermediate',
      keywords: ['Python', 'MATLAB', 'VBA', 'JavaScript', 'Node.js'],
    },
    {
      id: '5',
      name: 'PLM',
      level: 'Expert',
      keywords: ['Windchill (design data management, ECR/ECO workflows)'],
    },
  ],
  projects: [
    {
      id: '1',
      name: 'DOOT Service Robot',
      description: 'Designed mechanical architecture for wireless-controlled COVID-19 ward service robot; integrated HMI, audio-visual, and remote operator interface; delivered 2 production units.',
      url: '',
      startDate: '2020',
      endDate: '2020',
    },
    {
      id: '2',
      name: 'Emergency Ventilator',
      description: 'Designed low-cost electromechanical ventilator from concept to fabrication; owned full lifecycle across mechanical, pneumatic, and electronics subsystems; prototyped and supplied 10 units during COVID-19 crisis.',
      url: '',
      startDate: '2020',
      endDate: '2020',
    },
  ],
}
